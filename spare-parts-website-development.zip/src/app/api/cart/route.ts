import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { cartItems, products } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import { cookies } from "next/headers";
import { v4 as uuidv4 } from "uuid";

export async function GET() {
  try {
    const cookieStore = await cookies();
    const sessionId = cookieStore.get("session_id")?.value;
    if (!sessionId) {
      return NextResponse.json({ items: [], total: 0 });
    }

    const items = await db
      .select({
        id: cartItems.id,
        quantity: cartItems.quantity,
        productId: cartItems.productId,
        name: products.nameFa,
        price: products.price,
        imageUrl: products.imageUrl,
        brand: products.brand,
        stock: products.stock,
      })
      .from(cartItems)
      .innerJoin(products, eq(cartItems.productId, products.id))
      .where(eq(cartItems.sessionId, sessionId));

    const total = items.reduce(
      (sum, item) => sum + Number(item.price) * item.quantity,
      0
    );

    return NextResponse.json({ items, total });
  } catch (error) {
    console.error("Cart GET error:", error);
    return NextResponse.json(
      { error: "خطا در دریافت سبد خرید" },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const cookieStore = await cookies();
    let sessionId = cookieStore.get("session_id")?.value;
    if (!sessionId) {
      sessionId = uuidv4();
    }

    const { productId, quantity = 1 } = await req.json();

    const existing = await db
      .select()
      .from(cartItems)
      .where(
        and(
          eq(cartItems.sessionId, sessionId),
          eq(cartItems.productId, productId)
        )
      );

    if (existing.length > 0) {
      await db
        .update(cartItems)
        .set({ quantity: existing[0].quantity + quantity })
        .where(eq(cartItems.id, existing[0].id));
    } else {
      await db
        .insert(cartItems)
        .values({ sessionId: sessionId, productId, quantity });
    }

    const response = NextResponse.json({ success: true });
    response.cookies.set("session_id", sessionId, {
      maxAge: 60 * 60 * 24 * 30,
      httpOnly: true,
    });
    return response;
  } catch (error) {
    console.error("Cart POST error:", error);
    return NextResponse.json(
      { error: "خطا در افزودن به سبد" },
      { status: 500 }
    );
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const cookieStore = await cookies();
    const sessionId = cookieStore.get("session_id")?.value;
    if (!sessionId) {
      return NextResponse.json({ success: true });
    }

    const { itemId } = await req.json();
    await db
      .delete(cartItems)
      .where(
        and(eq(cartItems.id, itemId), eq(cartItems.sessionId, sessionId))
      );

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Cart DELETE error:", error);
    return NextResponse.json(
      { error: "خطا در حذف از سبد" },
      { status: 500 }
    );
  }
}
