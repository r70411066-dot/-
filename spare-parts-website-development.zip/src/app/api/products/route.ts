import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { products } from "@/db/schema";
import { eq, ilike, or, and, desc, asc, sql } from "drizzle-orm";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const category = searchParams.get("category");
    const search = searchParams.get("search");
    const featured = searchParams.get("featured");
    const sort = searchParams.get("sort") || "newest";
    const page = parseInt(searchParams.get("page") || "1");
    const limit = parseInt(searchParams.get("limit") || "12");
    const offset = (page - 1) * limit;

    const conditions = [];

    if (category && category !== "all") {
      conditions.push(eq(products.category, category as any));
    }

    if (search) {
      conditions.push(
        or(
          ilike(products.name, `%${search}%`),
          ilike(products.nameFa, `%${search}%`),
          ilike(products.brand, `%${search}%`),
          ilike(products.partNumber, `%${search}%`)
        )
      );
    }

    if (featured === "true") {
      conditions.push(eq(products.isFeatured, true));
    }

    const whereClause =
      conditions.length > 0 ? and(...conditions) : undefined;

    let orderBy;
    switch (sort) {
      case "price-asc":
        orderBy = asc(sql`CAST(${products.price} AS NUMERIC)`);
        break;
      case "price-desc":
        orderBy = desc(sql`CAST(${products.price} AS NUMERIC)`);
        break;
      case "rating":
        orderBy = desc(products.rating);
        break;
      default:
        orderBy = desc(products.createdAt);
    }

    const [items, countResult] = await Promise.all([
      db
        .select()
        .from(products)
        .where(whereClause)
        .orderBy(orderBy)
        .limit(limit)
        .offset(offset),
      db
        .select({ count: sql<number>`count(*)` })
        .from(products)
        .where(whereClause),
    ]);

    const total = Number(countResult[0]?.count ?? 0);

    return NextResponse.json({
      products: items,
      total,
      page,
      totalPages: Math.ceil(total / limit),
    });
  } catch (error) {
    console.error("Products GET error:", error);
    return NextResponse.json(
      { error: "خطا در دریافت محصولات" },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const [product] = await db.insert(products).values(body).returning();
    return NextResponse.json(product, { status: 201 });
  } catch (error) {
    console.error("Products POST error:", error);
    return NextResponse.json(
      { error: "خطا در ایجاد محصول" },
      { status: 500 }
    );
  }
}
