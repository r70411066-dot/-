import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "پارت‌پلاس | فروشگاه تخصصی لوازم یدکی خودرو",
  description:
    "فروشگاه تخصصی لوازم یدکی با بیش از ۱۰۰۰۰ قطعه اصلی و غیراصلی برای انواع خودروهای ایرانی و خارجی",
  keywords: "لوازم یدکی, قطعات خودرو, پارت یدکی, موتور, ترمز, تعلیق",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="fa" dir="rtl">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link
          rel="preconnect"
          href="https://fonts.gstatic.com"
          crossOrigin="anonymous"
        />
        <link
          href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;600;700;800;900&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="antialiased">{children}</body>
    </html>
  );
}
