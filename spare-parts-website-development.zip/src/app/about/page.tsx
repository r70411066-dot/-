import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />

      {/* Hero */}
      <div
        className="relative pt-32 pb-20 overflow-hidden"
        style={{
          background: "linear-gradient(135deg, #1a1a2e 0%, #d4001a 100%)",
        }}
      >
        <div className="max-w-4xl mx-auto px-4 text-center text-white">
          <h1 className="text-5xl font-black mb-4">درباره پارت‌پلاس</h1>
          <p className="text-gray-300 text-xl">
            بیش از ۱۵ سال تجربه در تأمین لوازم یدکی باکیفیت
          </p>
        </div>
      </div>

      {/* Story */}
      <section className="py-20 bg-white">
        <div className="max-w-5xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-black text-gray-900 mb-6">
                داستان ما
              </h2>
              <p className="text-gray-600 leading-relaxed mb-4">
                پارت‌پلاس در سال ۱۳۸۸ با هدف ایجاد یک مرجع قابل اعتماد برای
                تأمین لوازم یدکی خودرو تأسیس شد. از ابتدا، تمرکز ما بر کیفیت،
                اصالت قطعه، و رضایت مشتری بوده است.
              </p>
              <p className="text-gray-600 leading-relaxed mb-4">
                با گذشت سال‌ها، توانستیم به یکی از معتبرترین فروشگاه‌های
                آنلاین لوازم یدکی در ایران تبدیل شویم و اکنون بیش از ۵۰٬۰۰۰
                مشتری فعال داریم.
              </p>
              <p className="text-gray-600 leading-relaxed">
                تمامی قطعات ما مستقیماً از نمایندگی‌های رسمی برندهای معتبر
                جهانی تأمین می‌شوند و دارای ضمانت اصالت هستند.
              </p>
            </div>
            <div className="relative">
              <img
                src="https://images.pexels.com/photos/4116222/pexels-photo-4116222.jpeg?auto=compress&cs=tinysrgb&w=600"
                alt="درباره ما"
                className="rounded-3xl shadow-2xl w-full"
              />
              <div className="absolute -bottom-6 -right-6 bg-red-600 text-white rounded-2xl p-5 shadow-xl">
                <p className="text-3xl font-black">۱۵+</p>
                <p className="text-sm">سال تجربه</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-5xl mx-auto px-4">
          <h2 className="text-3xl font-black text-gray-900 text-center mb-12">
            ارزش‌های ما
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                icon: "🏆",
                title: "کیفیت اول",
                desc: "هیچ قطعه‌ای بدون تأیید کیفیت به انبار ما راه پیدا نمی‌کند",
              },
              {
                icon: "🤝",
                title: "صداقت در کار",
                desc: "اطلاعات دقیق و شفاف درباره هر قطعه ارائه می‌دهیم",
              },
              {
                icon: "💡",
                title: "نوآوری مستمر",
                desc: "همیشه در حال بهبود تجربه خرید مشتریان هستیم",
              },
            ].map((val) => (
              <div
                key={val.title}
                className="bg-white rounded-2xl p-8 shadow-sm text-center border border-gray-100 hover:shadow-md transition-all"
              >
                <div className="text-5xl mb-4">{val.icon}</div>
                <h3 className="font-black text-gray-900 text-xl mb-3">
                  {val.title}
                </h3>
                <p className="text-gray-600 leading-relaxed">{val.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team Stats */}
      <section className="py-20 bg-gray-900 text-white">
        <div className="max-w-5xl mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            {[
              { value: "۵۰٬۰۰۰+", label: "مشتری راضی" },
              { value: "۱۰٬۰۰۰+", label: "قطعه موجود" },
              { value: "۵۰+", label: "برند معتبر" },
              { value: "۱۵+", label: "سال تجربه" },
            ].map((stat) => (
              <div key={stat.label}>
                <p className="text-4xl font-black text-red-400 mb-2">
                  {stat.value}
                </p>
                <p className="text-gray-400">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
