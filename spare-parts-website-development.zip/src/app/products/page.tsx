"use client";

import { useState, useEffect, useCallback, Suspense } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import ProductCard from "@/components/ProductCard";
import type { Product } from "@/db/schema";

const categories = [
  { id: "all", label: "همه", icon: "🔍" },
  { id: "engine", label: "موتور", icon: "⚙️" },
  { id: "brake", label: "ترمز", icon: "🔴" },
  { id: "suspension", label: "تعلیق", icon: "🔧" },
  { id: "electrical", label: "برق", icon: "⚡" },
  { id: "cooling", label: "خنک‌کننده", icon: "❄️" },
  { id: "body", label: "بدنه", icon: "🚗" },
  { id: "transmission", label: "گیربکس", icon: "🔩" },
  { id: "fuel", label: "سوخت", icon: "⛽" },
  { id: "exhaust", label: "اگزوز", icon: "💨" },
];

function ProductsContent() {
  const searchParams = useSearchParams();
  const router = useRouter();

  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [total, setTotal] = useState(0);
  const [totalPages, setTotalPages] = useState(1);

  const category = searchParams.get("category") || "all";
  const search = searchParams.get("search") || "";
  const sort = searchParams.get("sort") || "newest";
  const featured = searchParams.get("featured") || "";
  const page = parseInt(searchParams.get("page") || "1");

  const [searchInput, setSearchInput] = useState(search);

  const fetchProducts = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (category && category !== "all") params.set("category", category);
      if (search) params.set("search", search);
      if (sort) params.set("sort", sort);
      if (featured) params.set("featured", featured);
      params.set("page", String(page));
      params.set("limit", "12");

      const res = await fetch(`/api/products?${params.toString()}`);
      const data = await res.json();
      setProducts(data.products || []);
      setTotal(data.total || 0);
      setTotalPages(data.totalPages || 1);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  }, [category, search, sort, featured, page]);

  useEffect(() => {
    fetchProducts();
  }, [fetchProducts]);

  const updateParam = (key: string, value: string) => {
    const params = new URLSearchParams(searchParams.toString());
    if (value && value !== "all") {
      params.set(key, value);
    } else {
      params.delete(key);
    }
    params.delete("page");
    router.push(`/products?${params.toString()}`);
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    updateParam("search", searchInput);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />

      {/* Page Header */}
      <div
        className="relative pt-24 pb-12 overflow-hidden"
        style={{
          background: "linear-gradient(135deg, #1a1a2e 0%, #16213e 100%)",
        }}
      >
        <div className="absolute inset-0 opacity-10">
          <div
            className="w-full h-full bg-cover bg-center"
            style={{
              backgroundImage:
                "url(https://images.pexels.com/photos/4116192/pexels-photo-4116192.jpeg?auto=compress&cs=tinysrgb&w=1200)",
            }}
          />
        </div>
        <div className="relative max-w-7xl mx-auto px-4">
          <h1 className="text-4xl font-black text-white mb-2">
            {featured ? "محصولات ویژه 🌟" : "فروشگاه لوازم یدکی"}
          </h1>
          <p className="text-gray-400">
            {total > 0
              ? `${total.toLocaleString("fa-IR")} محصول یافت شد`
              : "جستجو در بیش از ۱۰٬۰۰۰ قطعه خودرو"}
          </p>

          {/* Search */}
          <form onSubmit={handleSearch} className="mt-6 max-w-xl">
            <div className="flex gap-2">
              <input
                type="text"
                value={searchInput}
                onChange={(e) => setSearchInput(e.target.value)}
                placeholder="جستجو در محصولات..."
                className="flex-1 bg-white/10 border border-white/20 text-white placeholder-gray-400 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-red-400 focus:bg-white/15 transition-all"
              />
              <button
                type="submit"
                className="bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-xl text-sm font-bold transition-colors"
              >
                جستجو
              </button>
            </div>
          </form>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Category Tabs */}
        <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-2 mb-8">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => updateParam("category", cat.id)}
              className={`flex-shrink-0 flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold transition-all ${
                category === cat.id
                  ? "bg-red-600 text-white shadow-lg shadow-red-200"
                  : "bg-white text-gray-600 hover:bg-red-50 hover:text-red-600 shadow-sm"
              }`}
            >
              <span>{cat.icon}</span>
              <span>{cat.label}</span>
            </button>
          ))}
        </div>

        {/* Sort Bar */}
        <div className="flex items-center justify-between mb-6">
          <p className="text-gray-500 text-sm">
            {total > 0
              ? `نمایش ${products.length} از ${total.toLocaleString("fa-IR")} محصول`
              : ""}
          </p>
          <div className="flex items-center gap-2">
            <span className="text-sm text-gray-500">مرتب‌سازی:</span>
            <select
              value={sort}
              onChange={(e) => updateParam("sort", e.target.value)}
              className="text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white text-gray-700 focus:outline-none focus:border-red-400"
            >
              <option value="newest">جدیدترین</option>
              <option value="price-asc">ارزان‌ترین</option>
              <option value="price-desc">گران‌ترین</option>
              <option value="rating">بهترین امتیاز</option>
            </select>
          </div>
        </div>

        {/* Products Grid */}
        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="bg-white rounded-2xl overflow-hidden shadow-md">
                <div className="h-52 shimmer" />
                <div className="p-4 space-y-3">
                  <div className="h-4 shimmer rounded-lg w-3/4" />
                  <div className="h-3 shimmer rounded-lg w-1/2" />
                  <div className="h-6 shimmer rounded-lg w-1/3" />
                  <div className="h-10 shimmer rounded-xl" />
                </div>
              </div>
            ))}
          </div>
        ) : products.length === 0 ? (
          <div className="text-center py-24 bg-white rounded-3xl shadow-sm">
            <div className="text-7xl mb-4">🔍</div>
            <h3 className="text-2xl font-bold text-gray-700 mb-2">
              محصولی یافت نشد
            </h3>
            <p className="text-gray-500 mb-6">
              دسته یا فیلتر دیگری را امتحان کنید
            </p>
            <button
              onClick={() => router.push("/products")}
              className="bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-xl font-bold transition-colors"
            >
              مشاهده همه محصولات
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {products.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex justify-center gap-2 mt-10">
            <button
              onClick={() => updateParam("page", String(page - 1))}
              disabled={page <= 1}
              className="px-4 py-2 bg-white border border-gray-200 rounded-xl text-sm font-medium text-gray-700 hover:bg-red-50 hover:border-red-300 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
            >
              قبلی
            </button>
            {Array.from({ length: Math.min(totalPages, 7) }, (_, i) => {
              const p = i + 1;
              return (
                <button
                  key={p}
                  onClick={() => updateParam("page", String(p))}
                  className={`px-4 py-2 rounded-xl text-sm font-medium transition-colors ${
                    page === p
                      ? "bg-red-600 text-white shadow-md"
                      : "bg-white border border-gray-200 text-gray-700 hover:bg-red-50 hover:border-red-300"
                  }`}
                >
                  {p.toLocaleString("fa-IR")}
                </button>
              );
            })}
            <button
              onClick={() => updateParam("page", String(page + 1))}
              disabled={page >= totalPages}
              className="px-4 py-2 bg-white border border-gray-200 rounded-xl text-sm font-medium text-gray-700 hover:bg-red-50 hover:border-red-300 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
            >
              بعدی
            </button>
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
}

export default function ProductsPage() {
  return (
    <Suspense>
      <ProductsContent />
    </Suspense>
  );
}
