"use client";

import { useState, useEffect } from "react";
import { useParams, useRouter } from "next/navigation";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import type { Product } from "@/db/schema";

const categoryLabels: Record<string, string> = {
  engine: "موتور",
  brake: "ترمز",
  suspension: "تعلیق",
  electrical: "برق",
  body: "بدنه",
  transmission: "گیربکس",
  cooling: "خنک‌کننده",
  fuel: "سوخت",
  exhaust: "اگزوز",
  other: "سایر",
};

export default function ProductDetailPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [quantity, setQuantity] = useState(1);
  const [adding, setAdding] = useState(false);
  const [added, setAdded] = useState(false);

  useEffect(() => {
    fetch(`/api/products/${id}`)
      .then((r) => r.json())
      .then((d) => {
        setProduct(d);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, [id]);

  const handleAddToCart = async () => {
    if (!product) return;
    setAdding(true);
    try {
      await fetch("/api/cart", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ productId: product.id, quantity }),
      });
      setAdded(true);
      window.dispatchEvent(new Event("cart-updated"));
      setTimeout(() => setAdded(false), 3000);
    } catch {}
    setAdding(false);
  };

  const discount =
    product?.originalPrice
      ? Math.round(
          ((Number(product.originalPrice) - Number(product.price)) /
            Number(product.originalPrice)) *
            100
        )
      : 0;

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="max-w-7xl mx-auto px-4 pt-32">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
            <div className="h-96 shimmer rounded-3xl" />
            <div className="space-y-4">
              <div className="h-8 shimmer rounded-xl w-3/4" />
              <div className="h-4 shimmer rounded-xl w-1/2" />
              <div className="h-12 shimmer rounded-xl w-1/3" />
              <div className="h-40 shimmer rounded-xl" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="text-6xl mb-4">😕</div>
          <h2 className="text-2xl font-bold text-gray-700 mb-4">
            محصول یافت نشد
          </h2>
          <button
            onClick={() => router.push("/products")}
            className="bg-red-600 text-white px-6 py-3 rounded-xl font-bold"
          >
            بازگشت به فروشگاه
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />

      <div className="max-w-7xl mx-auto px-4 pt-24 pb-16">
        {/* Breadcrumb */}
        <nav className="flex items-center gap-2 text-sm text-gray-500 mb-8">
          <button onClick={() => router.push("/")} className="hover:text-red-600 transition-colors">
            خانه
          </button>
          <span>›</span>
          <button onClick={() => router.push("/products")} className="hover:text-red-600 transition-colors">
            محصولات
          </button>
          <span>›</span>
          <span className="text-gray-900 font-medium">{product.nameFa}</span>
        </nav>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Image */}
          <div className="relative">
            <div className="relative overflow-hidden rounded-3xl bg-white shadow-xl aspect-square">
              {product.imageUrl ? (
                <img
                  src={product.imageUrl}
                  alt={product.nameFa}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center bg-gray-100">
                  <div className="text-8xl">⚙️</div>
                </div>
              )}

              {discount > 0 && (
                <div className="absolute top-4 right-4 bg-red-600 text-white text-lg font-black px-4 py-2 rounded-2xl shadow-lg">
                  {discount}٪ تخفیف
                </div>
              )}
            </div>

            {/* Trust badges */}
            <div className="grid grid-cols-3 gap-3 mt-4">
              {[
                { icon: "✅", text: "گارانتی اصالت" },
                { icon: "🚚", text: "ارسال سریع" },
                { icon: "🔄", text: "۷ روز مرجوعی" },
              ].map((badge) => (
                <div
                  key={badge.text}
                  className="bg-white rounded-xl p-3 text-center shadow-sm border border-gray-100"
                >
                  <div className="text-xl mb-1">{badge.icon}</div>
                  <p className="text-xs text-gray-600 font-medium">{badge.text}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Details */}
          <div className="flex flex-col">
            {/* Category & badges */}
            <div className="flex flex-wrap items-center gap-2 mb-4">
              <span className="bg-red-100 text-red-700 text-sm font-semibold px-3 py-1 rounded-xl">
                {categoryLabels[product.category] ?? product.category}
              </span>
              {product.isOriginal && (
                <span className="bg-green-100 text-green-700 text-sm font-semibold px-3 py-1 rounded-xl">
                  ✓ قطعه اصلی
                </span>
              )}
              {product.isFeatured && (
                <span className="bg-amber-100 text-amber-700 text-sm font-semibold px-3 py-1 rounded-xl">
                  ⭐ محصول ویژه
                </span>
              )}
            </div>

            <h1 className="text-3xl md:text-4xl font-black text-gray-900 mb-2 leading-tight">
              {product.nameFa}
            </h1>
            <p className="text-lg text-gray-500 mb-1">{product.name}</p>

            {/* Rating */}
            {Number(product.rating) > 0 && (
              <div className="flex items-center gap-2 mb-6">
                <div className="flex">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <svg
                      key={star}
                      className={`w-5 h-5 ${
                        star <= Math.round(Number(product.rating))
                          ? "text-amber-400"
                          : "text-gray-200"
                      }`}
                      fill="currentColor"
                      viewBox="0 0 20 20"
                    >
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                  ))}
                </div>
                <span className="text-gray-600 text-sm font-medium">
                  {Number(product.rating).toFixed(1)}
                </span>
                <span className="text-gray-400 text-sm">
                  ({product.reviewCount?.toLocaleString("fa-IR")} نظر)
                </span>
              </div>
            )}

            {/* Specs */}
            <div className="bg-gray-50 rounded-2xl p-5 mb-6">
              <h3 className="font-bold text-gray-900 mb-3 text-sm uppercase tracking-wider">
                مشخصات فنی
              </h3>
              <div className="space-y-3">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">برند</span>
                  <span className="font-semibold text-gray-900">{product.brand}</span>
                </div>
                {product.model && (
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">مناسب برای</span>
                    <span className="font-semibold text-gray-900 text-left max-w-48">
                      {product.model}
                    </span>
                  </div>
                )}
                {product.partNumber && (
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">کد قطعه</span>
                    <span className="font-mono font-bold text-gray-900 bg-gray-200 px-2 py-0.5 rounded text-xs">
                      {product.partNumber}
                    </span>
                  </div>
                )}
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">وضعیت موجودی</span>
                  <span
                    className={`font-semibold ${
                      product.stock > 10
                        ? "text-green-600"
                        : product.stock > 0
                        ? "text-amber-600"
                        : "text-red-600"
                    }`}
                  >
                    {product.stock > 10
                      ? "موجود ✓"
                      : product.stock > 0
                      ? `تنها ${product.stock} عدد باقی مانده`
                      : "ناموجود"}
                  </span>
                </div>
              </div>
            </div>

            {/* Description */}
            {product.description && (
              <div className="mb-6">
                <h3 className="font-bold text-gray-900 mb-2">توضیحات</h3>
                <p className="text-gray-600 leading-relaxed text-sm">
                  {product.description}
                </p>
              </div>
            )}

            {/* Price & Buy */}
            <div className="bg-white border-2 border-gray-100 rounded-2xl p-5 mt-auto">
              <div className="flex items-end justify-between mb-4">
                <div>
                  {product.originalPrice &&
                    Number(product.originalPrice) > Number(product.price) && (
                      <p className="text-gray-400 line-through text-sm mb-1">
                        {Number(product.originalPrice).toLocaleString("fa-IR")} تومان
                      </p>
                    )}
                  <p className="text-3xl font-black text-red-600">
                    {Number(product.price).toLocaleString("fa-IR")}
                    <span className="text-base font-normal text-gray-500 mr-1">
                      تومان
                    </span>
                  </p>
                </div>
                {discount > 0 && (
                  <div className="text-center bg-red-50 text-red-600 rounded-xl p-2">
                    <p className="text-xl font-black">{discount}٪</p>
                    <p className="text-xs">تخفیف</p>
                  </div>
                )}
              </div>

              {/* Quantity */}
              <div className="flex items-center gap-3 mb-4">
                <span className="text-sm text-gray-600 font-medium">تعداد:</span>
                <div className="flex items-center border border-gray-200 rounded-xl overflow-hidden">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="w-10 h-10 flex items-center justify-center text-gray-600 hover:bg-gray-50 font-bold text-lg transition-colors"
                  >
                    −
                  </button>
                  <span className="w-12 h-10 flex items-center justify-center font-bold text-gray-900 border-x border-gray-200">
                    {quantity}
                  </span>
                  <button
                    onClick={() =>
                      setQuantity(Math.min(product.stock, quantity + 1))
                    }
                    className="w-10 h-10 flex items-center justify-center text-gray-600 hover:bg-gray-50 font-bold text-lg transition-colors"
                  >
                    +
                  </button>
                </div>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={handleAddToCart}
                  disabled={adding || product.stock === 0}
                  className={`flex-1 py-4 rounded-xl font-black text-base transition-all ${
                    added
                      ? "bg-green-500 text-white"
                      : product.stock === 0
                      ? "bg-gray-100 text-gray-400 cursor-not-allowed"
                      : "bg-red-600 hover:bg-red-700 text-white shadow-lg hover:shadow-red-200"
                  }`}
                >
                  {added
                    ? "✓ به سبد افزوده شد"
                    : adding
                    ? "در حال افزودن..."
                    : "🛒 افزودن به سبد خرید"}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
