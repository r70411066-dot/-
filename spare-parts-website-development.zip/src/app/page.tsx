import Link from "next/link";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import ProductCard from "@/components/ProductCard";
import { db } from "@/db";
import { products } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

async function getFeaturedProducts() {
  try {
    return await db
      .select()
      .from(products)
      .where(eq(products.isFeatured, true))
      .orderBy(desc(products.createdAt))
      .limit(8);
  } catch {
    return [];
  }
}

const categories = [
  { id: "engine", label: "موتور", icon: "⚙️", color: "from-orange-400 to-orange-600", count: "۲۵۰۰+ قطعه" },
  { id: "brake", label: "ترمز", icon: "🔴", color: "from-red-400 to-red-600", count: "۱۲۰۰+ قطعه" },
  { id: "suspension", label: "تعلیق", icon: "🔧", color: "from-blue-400 to-blue-600", count: "۸۰۰+ قطعه" },
  { id: "electrical", label: "برق", icon: "⚡", color: "from-yellow-400 to-yellow-600", count: "۱۵۰۰+ قطعه" },
  { id: "cooling", label: "خنک‌کننده", icon: "❄️", color: "from-cyan-400 to-cyan-600", count: "۶۰۰+ قطعه" },
  { id: "body", label: "بدنه", icon: "🚗", color: "from-green-400 to-green-600", count: "۹۰۰+ قطعه" },
  { id: "transmission", label: "گیربکس", icon: "🔩", color: "from-purple-400 to-purple-600", count: "۴۰۰+ قطعه" },
  { id: "fuel", label: "سوخت", icon: "⛽", color: "from-amber-400 to-amber-600", count: "۳۵۰+ قطعه" },
];

const stats = [
  { value: "۱۰٬۰۰۰+", label: "قطعه موجود", icon: "📦" },
  { value: "۱۵+", label: "سال تجربه", icon: "🏆" },
  { value: "۵۰٬۰۰۰+", label: "مشتری راضی", icon: "😊" },
  { value: "۲۴h", label: "پشتیبانی", icon: "🛎️" },
];

const brands = [
  { name: "Bosch", icon: "🔧" },
  { name: "NGK", icon: "⚡" },
  { name: "Gates", icon: "⚙️" },
  { name: "Brembo", icon: "🔴" },
  { name: "KYB", icon: "🔩" },
  { name: "Mann", icon: "🛢️" },
];

export default async function HomePage() {
  const featuredProducts = await getFeaturedProducts();

  return (
    <div className="min-h-screen">
      <Navbar />

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage:
              "url(https://images.pexels.com/photos/8985969/pexels-photo-8985969.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1600)",
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-l from-black/90 via-black/70 to-black/40" />

        <div className="relative max-w-7xl mx-auto px-4 py-32">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2 bg-red-600/20 border border-red-500/30 rounded-full px-4 py-2 mb-6">
              <span className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
              <span className="text-red-400 text-sm font-medium">
                بیش از ۱۰٬۰۰۰ قطعه آماده ارسال
              </span>
            </div>

            <h1 className="text-5xl md:text-7xl font-black text-white leading-tight mb-6 text-shadow">
              لوازم یدکی
              <br />
              <span className="text-red-500">اصلی و مطمئن</span>
              <br />
              <span className="text-3xl md:text-4xl font-bold text-gray-300">
                برای هر خودرویی
              </span>
            </h1>

            <p className="text-gray-300 text-lg md:text-xl leading-relaxed mb-8">
              با بیش از ۱۵ سال تجربه، قطعات اصلی و باکیفیت را با قیمت مناسب
              تهیه کنید. ارسال سریع به سراسر ایران.
            </p>

            <div className="flex flex-wrap gap-4">
              <Link
                href="/products"
                className="bg-red-600 hover:bg-red-700 text-white px-8 py-4 rounded-2xl text-lg font-bold transition-all shadow-2xl hover:shadow-red-500/25 hover:scale-105"
              >
                مشاهده محصولات
              </Link>
              <Link
                href="/products?featured=true"
                className="bg-white/10 backdrop-blur-sm border border-white/30 hover:bg-white/20 text-white px-8 py-4 rounded-2xl text-lg font-bold transition-all"
              >
                پیشنهادهای ویژه
              </Link>
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-12">
              {stats.map((stat) => (
                <div
                  key={stat.label}
                  className="bg-white/10 backdrop-blur-sm border border-white/10 rounded-2xl p-4 text-center"
                >
                  <div className="text-2xl mb-1">{stat.icon}</div>
                  <div className="text-2xl font-black text-white">
                    {stat.value}
                  </div>
                  <div className="text-gray-400 text-xs">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 animate-bounce">
          <span className="text-gray-400 text-xs">پایین بروید</span>
          <svg
            className="w-5 h-5 text-gray-400"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M19 9l-7 7-7-7"
            />
          </svg>
        </div>
      </section>

      {/* Categories */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-black text-gray-900 mb-4">
              دسته‌بندی‌ها
            </h2>
            <p className="text-gray-500 text-lg">
              قطعات مورد نیاز خود را بر اساس دسته بیابید
            </p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {categories.map((cat) => (
              <Link
                key={cat.id}
                href={`/products?category=${cat.id}`}
                className="group relative overflow-hidden rounded-2xl p-6 text-center transition-all hover:scale-105 hover:shadow-xl cursor-pointer"
              >
                <div
                  className={`absolute inset-0 bg-gradient-to-br ${cat.color} opacity-10 group-hover:opacity-20 transition-opacity`}
                />
                <div className="relative">
                  <div className="text-4xl mb-3">{cat.icon}</div>
                  <h3 className="font-bold text-gray-900 text-base mb-1">
                    {cat.label}
                  </h3>
                  <p className="text-xs text-gray-500">{cat.count}</p>
                </div>
                <div
                  className={`absolute bottom-0 right-0 left-0 h-1 bg-gradient-to-r ${cat.color} transform translate-y-full group-hover:translate-y-0 transition-transform rounded-b-2xl`}
                />
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Features Banner */}
      <section className="py-14 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[
              {
                icon: "🚚",
                title: "ارسال رایگان",
                desc: "برای سفارش‌های بالای ۵۰۰ هزار تومان",
                color: "border-blue-200 bg-blue-50",
              },
              {
                icon: "✅",
                title: "ضمانت اصالت",
                desc: "تمامی قطعات دارای گارانتی اصالت",
                color: "border-green-200 bg-green-50",
              },
              {
                icon: "🔄",
                title: "۷ روز مرجوعی",
                desc: "بدون قید و شرط، راحت برگردانید",
                color: "border-purple-200 bg-purple-50",
              },
              {
                icon: "🛎️",
                title: "پشتیبانی ۲۴ساعته",
                desc: "متخصصان ما آماده راهنمایی شما",
                color: "border-amber-200 bg-amber-50",
              },
            ].map((feature) => (
              <div
                key={feature.title}
                className={`${feature.color} border rounded-2xl p-6 flex flex-col items-center text-center transition-all hover:shadow-md`}
              >
                <div className="text-4xl mb-3">{feature.icon}</div>
                <h3 className="font-bold text-gray-900 text-base mb-2">
                  {feature.title}
                </h3>
                <p className="text-sm text-gray-600">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-end justify-between mb-12">
            <div>
              <h2 className="text-4xl font-black text-gray-900 mb-2">
                محصولات ویژه
              </h2>
              <p className="text-gray-500">پرفروش‌ترین و بهترین قطعات</p>
            </div>
            <Link
              href="/products"
              className="hidden md:flex items-center gap-2 text-red-600 font-bold hover:gap-3 transition-all"
            >
              مشاهده همه
              <svg
                className="w-5 h-5 rotate-180"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M9 5l7 7-7 7"
                />
              </svg>
            </Link>
          </div>

          {featuredProducts.length === 0 ? (
            <div className="text-center py-20 bg-gray-50 rounded-3xl">
              <div className="text-6xl mb-4">🛠️</div>
              <h3 className="text-xl font-bold text-gray-700 mb-2">
                محصولی یافت نشد
              </h3>
              <p className="text-gray-500 mb-6">
                برای مشاهده نمونه محصولات، روی دکمه زیر کلیک کنید
              </p>
              <form action="/api/seed" method="POST">
                <button
                  type="submit"
                  className="bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-xl font-bold"
                >
                  بارگذاری محصولات نمونه
                </button>
              </form>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {featuredProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}

          <div className="text-center mt-8 md:hidden">
            <Link
              href="/products"
              className="inline-block bg-red-600 hover:bg-red-700 text-white px-8 py-3 rounded-xl font-bold transition-colors"
            >
              مشاهده همه محصولات
            </Link>
          </div>
        </div>
      </section>

      {/* Brands */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-10">
            <h2 className="text-3xl font-black text-gray-900 mb-2">
              برندهای معتبر
            </h2>
            <p className="text-gray-500">نمایندگی رسمی بهترین برندهای جهانی</p>
          </div>
          <div className="flex flex-wrap justify-center items-center gap-8 md:gap-12">
            {brands.map((brand) => (
              <div
                key={brand.name}
                className="bg-white rounded-2xl px-8 py-5 shadow-sm hover:shadow-md transition-all hover:scale-105 cursor-pointer text-center"
              >
                <div className="text-3xl mb-2">{brand.icon}</div>
                <p className="font-black text-gray-700 text-base">{brand.name}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Banner */}
      <section className="py-20 relative overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage:
              "url(https://images.pexels.com/photos/4116222/pexels-photo-4116222.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=500&w=1600)",
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-red-900/95 to-gray-900/90" />
        <div className="relative max-w-4xl mx-auto px-4 text-center text-white">
          <h2 className="text-4xl md:text-5xl font-black mb-4">
            نیاز به راهنمایی دارید؟
          </h2>
          <p className="text-xl text-gray-300 mb-8">
            متخصصان ما آماده‌اند تا بهترین قطعه را برای خودروی شما پیدا کنند
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <a
              href="tel:02144123456"
              className="bg-white text-red-600 px-8 py-4 rounded-2xl font-black text-lg hover:bg-gray-100 transition-all hover:scale-105 shadow-2xl"
            >
              📞 ۰۲۱-۴۴۱۲۳۴۵۶
            </a>
            <a
              href="https://wa.me/989123456789"
              className="bg-green-500 text-white px-8 py-4 rounded-2xl font-black text-lg hover:bg-green-600 transition-all hover:scale-105 shadow-2xl"
            >
              💬 واتساپ
            </a>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
