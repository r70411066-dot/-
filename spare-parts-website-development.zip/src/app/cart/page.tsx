"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

interface CartItem {
  id: number;
  productId: number;
  quantity: number;
  name: string;
  price: string;
  imageUrl: string | null;
  brand: string;
  stock: number;
}

export default function CartPage() {
  const [items, setItems] = useState<CartItem[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [removing, setRemoving] = useState<number | null>(null);

  const fetchCart = async () => {
    try {
      const res = await fetch("/api/cart");
      const data = await res.json();
      setItems(data.items || []);
      setTotal(data.total || 0);
    } catch {}
    setLoading(false);
  };

  useEffect(() => {
    fetchCart();
  }, []);

  const removeItem = async (itemId: number) => {
    setRemoving(itemId);
    try {
      await fetch("/api/cart", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ itemId }),
      });
      window.dispatchEvent(new Event("cart-updated"));
      fetchCart();
    } catch {}
    setRemoving(null);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />

      <div className="max-w-5xl mx-auto px-4 pt-24 pb-16">
        <div className="flex items-center gap-3 mb-8">
          <div className="w-10 h-10 bg-red-100 rounded-xl flex items-center justify-center">
            <svg
              className="w-5 h-5 text-red-600"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"
              />
            </svg>
          </div>
          <h1 className="text-2xl font-black text-gray-900">سبد خرید</h1>
        </div>

        {loading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-28 shimmer rounded-2xl" />
            ))}
          </div>
        ) : items.length === 0 ? (
          <div className="text-center py-24 bg-white rounded-3xl shadow-sm">
            <div className="text-7xl mb-6">🛒</div>
            <h2 className="text-2xl font-bold text-gray-700 mb-2">
              سبد خرید خالی است
            </h2>
            <p className="text-gray-500 mb-8">
              به فروشگاه بروید و محصولات مورد نیاز خود را انتخاب کنید
            </p>
            <Link
              href="/products"
              className="inline-block bg-red-600 hover:bg-red-700 text-white px-8 py-4 rounded-2xl font-bold text-lg transition-colors shadow-lg"
            >
              رفتن به فروشگاه
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Items */}
            <div className="lg:col-span-2 space-y-4">
              {items.map((item) => (
                <div
                  key={item.id}
                  className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100 flex gap-4"
                >
                  {/* Image */}
                  <div className="w-24 h-24 rounded-xl overflow-hidden bg-gray-100 flex-shrink-0">
                    {item.imageUrl ? (
                      <img
                        src={item.imageUrl}
                        alt={item.name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-3xl">
                        ⚙️
                      </div>
                    )}
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <h3 className="font-bold text-gray-900 text-base mb-0.5 line-clamp-1">
                      {item.name}
                    </h3>
                    <p className="text-sm text-gray-500 mb-2">{item.brand}</p>
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-500">
                          {item.quantity} × {Number(item.price).toLocaleString("fa-IR")}
                        </p>
                        <p className="font-black text-red-600">
                          {(Number(item.price) * item.quantity).toLocaleString("fa-IR")}{" "}
                          <span className="text-xs font-normal text-gray-500">تومان</span>
                        </p>
                      </div>
                      <button
                        onClick={() => removeItem(item.id)}
                        disabled={removing === item.id}
                        className="text-gray-400 hover:text-red-500 transition-colors p-2 hover:bg-red-50 rounded-lg"
                      >
                        {removing === item.id ? (
                          <span className="text-sm">...</span>
                        ) : (
                          <svg
                            className="w-5 h-5"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth={2}
                              d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"
                            />
                          </svg>
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              ))}

              <Link
                href="/products"
                className="flex items-center gap-2 text-red-600 font-medium hover:gap-3 transition-all text-sm mt-4"
              >
                <svg
                  className="w-4 h-4"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M15 19l-7-7 7-7"
                  />
                </svg>
                ادامه خرید
              </Link>
            </div>

            {/* Summary */}
            <div className="lg:col-span-1">
              <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 sticky top-24">
                <h2 className="font-black text-gray-900 text-lg mb-6">
                  خلاصه سفارش
                </h2>

                <div className="space-y-3 mb-6">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">
                      تعداد محصولات ({items.length})
                    </span>
                    <span className="font-medium">
                      {total.toLocaleString("fa-IR")} تومان
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">هزینه ارسال</span>
                    <span className="text-green-600 font-medium">رایگان</span>
                  </div>
                  <div className="border-t border-gray-100 pt-3">
                    <div className="flex justify-between">
                      <span className="font-bold text-gray-900">مجموع</span>
                      <span className="font-black text-xl text-red-600">
                        {total.toLocaleString("fa-IR")} تومان
                      </span>
                    </div>
                  </div>
                </div>

                <button className="w-full bg-red-600 hover:bg-red-700 text-white py-4 rounded-xl font-black text-base transition-all shadow-lg hover:shadow-red-200">
                  تکمیل خرید
                </button>

                <div className="mt-4 flex items-center justify-center gap-2">
                  <span className="text-gray-400 text-xs">🔒 پرداخت امن</span>
                  <span className="text-gray-300">•</span>
                  <span className="text-gray-400 text-xs">✅ ضمانت اصالت</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
}
