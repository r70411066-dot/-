"use client";

import { useState } from "react";
import Link from "next/link";
import type { Product } from "@/db/schema";

interface ProductCardProps {
  product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
  const [adding, setAdding] = useState(false);
  const [added, setAdded] = useState(false);

  const discount =
    product.originalPrice
      ? Math.round(
          ((Number(product.originalPrice) - Number(product.price)) /
            Number(product.originalPrice)) *
            100
        )
      : 0;

  const handleAddToCart = async (e: React.MouseEvent) => {
    e.preventDefault();
    setAdding(true);
    try {
      await fetch("/api/cart", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ productId: product.id, quantity: 1 }),
      });
      setAdded(true);
      window.dispatchEvent(new Event("cart-updated"));
      setTimeout(() => setAdded(false), 2000);
    } catch {}
    setAdding(false);
  };

  const categoryLabels: Record<string, string> = {
    engine: "موتور",
    brake: "ترمز",
    suspension: "تعلیق",
    electrical: "برق",
    body: "بدنه",
    transmission: "گیربکس",
    cooling: "خنک‌کننده",
    fuel: "سوخت",
    exhaust: "اگزوز",
    other: "سایر",
  };

  const categoryColors: Record<string, string> = {
    engine: "bg-orange-100 text-orange-700",
    brake: "bg-red-100 text-red-700",
    suspension: "bg-blue-100 text-blue-700",
    electrical: "bg-yellow-100 text-yellow-700",
    body: "bg-green-100 text-green-700",
    transmission: "bg-purple-100 text-purple-700",
    cooling: "bg-cyan-100 text-cyan-700",
    fuel: "bg-amber-100 text-amber-700",
    exhaust: "bg-gray-100 text-gray-700",
    other: "bg-slate-100 text-slate-700",
  };

  return (
    <Link href={`/products/${product.id}`} className="block">
      <div className="bg-white rounded-2xl overflow-hidden shadow-md card-hover border border-gray-100 h-full flex flex-col">
        {/* Image */}
        <div className="relative overflow-hidden bg-gray-50 h-52">
          {product.imageUrl ? (
            <img
              src={product.imageUrl}
              alt={product.nameFa}
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <svg
                className="w-16 h-16 text-gray-300"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={1}
                  d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"
                />
              </svg>
            </div>
          )}

          {/* Badges */}
          <div className="absolute top-3 right-3 flex flex-col gap-1">
            {discount > 0 && (
              <span className="bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-lg shadow">
                {discount}٪ تخفیف
              </span>
            )}
            {product.isOriginal && (
              <span className="bg-green-500 text-white text-xs font-bold px-2 py-1 rounded-lg shadow">
                اصلی
              </span>
            )}
          </div>

          {product.stock === 0 && (
            <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
              <span className="bg-white text-gray-800 font-bold px-4 py-2 rounded-xl text-sm">
                ناموجود
              </span>
            </div>
          )}
        </div>

        {/* Info */}
        <div className="p-4 flex flex-col flex-1">
          <div className="flex items-center gap-2 mb-2">
            <span
              className={`text-xs font-medium px-2 py-1 rounded-lg ${
                categoryColors[product.category] ?? "bg-gray-100 text-gray-700"
              }`}
            >
              {categoryLabels[product.category] ?? product.category}
            </span>
            {product.isFeatured && (
              <span className="text-xs bg-amber-100 text-amber-700 font-medium px-2 py-1 rounded-lg">
                ⭐ ویژه
              </span>
            )}
          </div>

          <h3 className="font-bold text-gray-900 text-base mb-1 line-clamp-2 leading-relaxed">
            {product.nameFa}
          </h3>
          <p className="text-sm text-gray-500 mb-1">{product.brand}</p>
          {product.model && (
            <p className="text-xs text-gray-400 mb-3 line-clamp-1">
              {product.model}
            </p>
          )}

          {/* Rating */}
          {Number(product.rating) > 0 && (
            <div className="flex items-center gap-1 mb-3">
              <div className="flex">
                {[1, 2, 3, 4, 5].map((star) => (
                  <svg
                    key={star}
                    className={`w-3.5 h-3.5 ${
                      star <= Math.round(Number(product.rating))
                        ? "text-amber-400"
                        : "text-gray-200"
                    }`}
                    fill="currentColor"
                    viewBox="0 0 20 20"
                  >
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                  </svg>
                ))}
              </div>
              <span className="text-xs text-gray-500">
                ({product.reviewCount ?? 0})
              </span>
            </div>
          )}

          <div className="mt-auto">
            {/* Price */}
            <div className="mb-3">
              {product.originalPrice &&
                Number(product.originalPrice) > Number(product.price) && (
                  <p className="text-sm text-gray-400 line-through mb-0.5">
                    {Number(product.originalPrice).toLocaleString("fa-IR")} تومان
                  </p>
                )}
              <p className="text-lg font-black text-red-600">
                {Number(product.price).toLocaleString("fa-IR")}{" "}
                <span className="text-sm font-normal text-gray-500">تومان</span>
              </p>
            </div>

            {/* Add to cart */}
            <button
              onClick={handleAddToCart}
              disabled={adding || product.stock === 0}
              className={`w-full py-2.5 rounded-xl text-sm font-bold transition-all ${
                added
                  ? "bg-green-500 text-white"
                  : product.stock === 0
                  ? "bg-gray-100 text-gray-400 cursor-not-allowed"
                  : "bg-red-600 hover:bg-red-700 text-white shadow-md hover:shadow-red-200"
              }`}
            >
              {added ? "✓ افزوده شد" : adding ? "..." : "افزودن به سبد"}
            </button>
          </div>
        </div>
      </div>
    </Link>
  );
}
