import Link from "next/link";

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white mt-20">
      <div className="max-w-7xl mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10">
          {/* Brand */}
          <div className="md:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 bg-red-600 rounded-xl flex items-center justify-center">
                <svg
                  className="w-6 h-6 text-white"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"
                  />
                </svg>
              </div>
              <span className="text-xl font-black">
                پارت<span className="text-red-500">پلاس</span>
              </span>
            </div>
            <p className="text-gray-400 text-sm leading-relaxed">
              فروشگاه تخصصی لوازم یدکی با بیش از ۱۵ سال تجربه در تأمین قطعات
              اصلی و باکیفیت برای انواع خودروها
            </p>
            <div className="flex gap-3 mt-5">
              {["instagram", "telegram", "whatsapp"].map((social) => (
                <a
                  key={social}
                  href="#"
                  className="w-9 h-9 bg-gray-800 hover:bg-red-600 rounded-lg flex items-center justify-center transition-colors text-gray-400 hover:text-white text-xs font-bold"
                >
                  {social === "instagram" ? "📷" : social === "telegram" ? "✈️" : "📱"}
                </a>
              ))}
            </div>
          </div>

          {/* Links */}
          <div>
            <h4 className="font-bold text-white mb-4 text-sm uppercase tracking-wider">
              دسترسی سریع
            </h4>
            <ul className="space-y-2">
              {[
                { href: "/", label: "صفحه اصلی" },
                { href: "/products", label: "همه محصولات" },
                { href: "/about", label: "درباره ما" },
                { href: "/contact", label: "تماس با ما" },
              ].map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="text-gray-400 hover:text-red-400 text-sm transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Categories */}
          <div>
            <h4 className="font-bold text-white mb-4 text-sm uppercase tracking-wider">
              دسته‌بندی‌ها
            </h4>
            <ul className="space-y-2">
              {[
                { href: "/products?category=engine", label: "قطعات موتور" },
                { href: "/products?category=brake", label: "ترمز" },
                { href: "/products?category=suspension", label: "تعلیق و فرمان" },
                { href: "/products?category=electrical", label: "برق و روشنایی" },
                { href: "/products?category=cooling", label: "سیستم خنک‌کننده" },
                { href: "/products?category=body", label: "بدنه و شیشه" },
              ].map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="text-gray-400 hover:text-red-400 text-sm transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-bold text-white mb-4 text-sm uppercase tracking-wider">
              تماس با ما
            </h4>
            <ul className="space-y-3">
              <li className="flex items-start gap-2 text-gray-400 text-sm">
                <span className="text-red-500 mt-0.5">📍</span>
                تهران، خیابان آزادی، مجتمع پارت‌پلاس
              </li>
              <li className="flex items-center gap-2 text-gray-400 text-sm">
                <span className="text-red-500">📞</span>
                ۰۲۱-۴۴۱۲۳۴۵۶
              </li>
              <li className="flex items-center gap-2 text-gray-400 text-sm">
                <span className="text-red-500">📱</span>
                ۰۹۱۲-۳۴۵۶۷۸۹
              </li>
              <li className="flex items-center gap-2 text-gray-400 text-sm">
                <span className="text-red-500">✉️</span>
                info@partplus.ir
              </li>
            </ul>
            <div className="mt-4 p-3 bg-gray-800 rounded-xl">
              <p className="text-xs text-gray-400">ساعات کاری</p>
              <p className="text-sm text-white font-medium">
                شنبه تا پنج‌شنبه: ۸ تا ۲۰
              </p>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-gray-500 text-sm">
            © ۱۴۰۴ پارت‌پلاس — تمامی حقوق محفوظ است
          </p>
          <div className="flex items-center gap-4">
            <img
              src="https://upload.wikimedia.org/wikipedia/commons/5/5e/Visa_Inc._logo.svg"
              alt="Visa"
              className="h-5 opacity-40 grayscale"
            />
            <span className="text-gray-600 text-xs">پرداخت امن</span>
            <div className="flex gap-1">
              {["🔒", "✅", "🛡️"].map((icon, i) => (
                <span key={i} className="text-gray-500 text-sm">
                  {icon}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
